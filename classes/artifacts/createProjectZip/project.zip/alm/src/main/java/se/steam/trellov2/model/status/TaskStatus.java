package se.steam.trellov2.model.status;

public enum TaskStatus {

    UNSTARTED, STARTED, PENDING, DONE
}