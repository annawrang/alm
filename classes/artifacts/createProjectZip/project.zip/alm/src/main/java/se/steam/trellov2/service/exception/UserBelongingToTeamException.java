package se.steam.trellov2.service.exception;

public final class UserBelongingToTeamException extends RuntimeException {

    public UserBelongingToTeamException(String s) {
        super(s);
    }
}
