package se.steam.trellov2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Trellov2Application {

    public static void main(String[] args) {
        SpringApplication.run(Trellov2Application.class, args);
    }
}
